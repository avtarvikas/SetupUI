export const baseEarning = [
  "Bereavement",
  "Bonus",
  "Commision",
  "Holiday",
  "Jury Duty",
  "Overtime",
  "Regular",
  "Other"
];

export const accural = ["Paid Time Off", "Personal"];

export const Tips = ["Tip Shortfall/MakeUp", "Personal"];

export const footerDescription =
  "Please read the Question and answer carefully";
