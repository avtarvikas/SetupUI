export const quizForm = [
  "Title",
  "Option_1",
  "Option_2",
  "Option_3",
  "Option_4"
];
