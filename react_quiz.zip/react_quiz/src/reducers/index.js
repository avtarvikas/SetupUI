import { combineReducers } from "redux";
import quizData from "../actions/quizData";

const rootReducer = combineReducers({ quizData });

export default rootReducer;
